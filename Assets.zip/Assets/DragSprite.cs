using UnityEngine;

public class DraggableSprite : MonoBehaviour
{
    private bool canDrag = true;
    private Vector3 offset;

    void OnMouseDown()
    {
        if (!canDrag) return;

        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorldPos.z = transform.position.z;
        offset = transform.position - mouseWorldPos;
    }

    void OnMouseDrag()
    {
        if (!canDrag) return;

        Vector3 mouseWorldPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mouseWorldPos.z = transform.position.z;
        transform.position = mouseWorldPos + offset;
    }

    public void ToggleDrag()
    {
        canDrag = !canDrag;
        Debug.Log("Arrastre activo: " + canDrag);
    }
}
