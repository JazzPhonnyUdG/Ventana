using UnityEngine;

public class MoveSprite : MonoBehaviour
{
    public void MoveRight()
    {
        transform.position += Vector3.right;
    }

    public void MoveLeft()
    {
        transform.position += Vector3.left;
    }
}
