using UnityEngine;

public class PlayerCollision : MonoBehaviour
{
    Animator animator;

    void Start()
    {
        animator = GetComponent<Animator>();
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        animator.SetTrigger("Explode");
    }
}